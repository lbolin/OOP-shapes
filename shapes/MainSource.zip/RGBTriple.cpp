#include"RGBTriple.h"

RGBTriple::RGBTriple() {}
RGBTriple::RGBTriple(unsigned char red, unsigned char green, unsigned char blue)
{
	Blue = blue;
	Green = green;
	Red = red;
}