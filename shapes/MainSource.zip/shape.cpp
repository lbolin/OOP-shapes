#include "shape.h"
#include "Picture.h"

bool shape::hasShadow = false;
int shape::xOffset = 0;
int shape::yOffset = 0;

shape::shape()
{

}


shape::~shape()
{
}


